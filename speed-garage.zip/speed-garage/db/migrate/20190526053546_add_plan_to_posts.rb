class AddPlanToPosts < ActiveRecord::Migration[5.2]
  def change
    add_column :posts, :plan, :string
  end
end
