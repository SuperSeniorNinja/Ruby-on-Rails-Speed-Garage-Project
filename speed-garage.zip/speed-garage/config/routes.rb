Rails.application.routes.draw do
  mount RailsAdmin::Engine => '/admin', as: 'rails_admin'
  resources :blogs
  resources :topics
  resources :posts do
    resources :features
  end
  resources :categories do
    resources :subcategories
  end

  resources :conversations do
  	resources :messages
  end

  devise_for :users

  root to: "home#index"
  get 'partners',  to: 'home#partners'
  get 'business-directory', to: 'home#business_directory'
  get 'contact', to: 'home#contact'
  get 'partner', to: 'home#partner'
  get 'about', to: 'home#about'
  get 'contact', to: 'home#contact'
  get 'myads', to: 'posts#myads'
end
