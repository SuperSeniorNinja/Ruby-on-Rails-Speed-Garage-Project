every 2.hours do
  # specify the task name as a string
  rake "posts"
end