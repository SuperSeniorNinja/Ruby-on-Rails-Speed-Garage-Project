# Load the Rails application.
require_relative 'application'

# Initialize the Rails application.
Rails.application.initialize!

ActionMailer::Base.smtp_settings = {
    address: 'smtp.mailgun.org',
    port: 587,
    domain: ENV['MAILGUN_DOMAIN'],
    authentication: 'plain',
    user_name: ENV['MAILGUN_USERNAME'],
    password: ENV['MAILGUN_PASSWORD']
  }
