document.addEventListener('turbolinks:load', function() {
    $('.js-carousel').slick({
      infinite: true,
      dots: true,
      arrows: true
    });
  })