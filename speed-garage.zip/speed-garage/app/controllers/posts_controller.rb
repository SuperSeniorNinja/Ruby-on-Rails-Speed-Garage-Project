class PostsController < ApplicationController
  before_action :authenticate_user!, only: [:new, :create, :update, :edit]
  before_action :set_post, only: [:show, :edit, :update, :destroy]
  before_action :restriction, only: [:edit, :update, :destroy]


  # GET /posts
  # GET /posts.json
  def index
    query = params[:q].presence || "*"
    @posts = Post.page(params[:page]).per(10).search(query)
    
    @categories = Category.all
    @oval = @categories[0]
    @atv = @categories[1]
    @boat = @categories[2]
    @fab = @categories[3]
    @chassis = @categories[4]
    @classic = @categories[5]
    @dirt = @categories[6]
    @dragracing = @categories[7]
    @audio = @categories[8]
    @engine = @categories[9]
    @tune = @categories[10]
    @enginecom = @categories[11]
    @exhaust = @categories[12]
    @golfcart = @categories[13]
    @hotrod = @categories[14]
    @karts = @categories[15]
    @modern = @categories[16]
    @motorcycle = @categories[17]
    @muscle = @categories[18]
    @offroad = @categories[19]
    @racingitem = @categories[20]
    @accessories = @categories[21]
    @position = @categories[22]
    @racingeq = @categories[23]
    @roadracing = @categories[24]
    @safety = @categories[25]
    @snowmobile = @categories[26]
    @tw = @categories[27]
    @tools = @categories[28]
    @rvs = @categories[29]
    @tractor = @categories[30]
    @trailer = @categories[31]
    @transmission = @categories[32]
    @truckpart = @categories[33]
    @drift = @categories[34]
    @import = @categories[35]
  end

  # GET /posts/1
  # GET /posts/1.json
  def show
    @posts = Post.all.order(created_at: :desc)
  end

  # GET /posts/new
  def new
    @post = Post.new
  end

  # GET /posts/1/edit
  def edit
  end

  # POST /posts
  # POST /posts.json
  def create
    @post = current_user.posts.build(post_params)

    respond_to do |format|
      if @post.save
        format.html { redirect_to @post, notice: 'Post was successfully created.' }
        format.json { render :show, status: :created, location: @post }
      else
        format.html { render :new }
        format.json { render json: @post.errors, status: :unprocessable_entity }
      end
    end

  rescue Stripe::CardError => e 
    flash.alert = e.message
    render action: :new
  end

  # PATCH/PUT /posts/1
  # PATCH/PUT /posts/1.json
  def update
    respond_to do |format|
      if @post.update(post_params)
        format.html { redirect_to @post, notice: 'Post was successfully updated.' }
        format.json { render :show, status: :ok, location: @post }
      else
        format.html { render :edit }
        format.json { render json: @post.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /posts/1
  # DELETE /posts/1.json
  def destroy
    @post.destroy
    respond_to do |format|
      format.html { redirect_to posts_url, notice: 'Post was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  def myads
    @posts = Post.where(user: current_user)
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_post
      @post = Post.friendly.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def post_params
      params.require(:post).permit(:title, :description, :email, :plan, :condition, :trades, :vin, :phone_number, :country, :state, :city, :price, :shipping, :category_id, :ad_number, :subcategory_id, :user_id, images: [])
    end

    def restriction
     unless @post.user_id == current_user.id
      flash[:notice] = 'You are not the owner of this Ad listing'
      redirect_to root_path
     end
    end

end
