class TopicsController < ApplicationController

	def show
		@topic = Topic.find(params[:id])
		@blogs = @topic.blogs.page(params[:page]).per(10).order(created_at: :desc)

		@topics = Topic.all
	    @dragracing = @topics[0]
	    @nascar = @topics[1]
	    @drifting = @topics[2]
	    @sprint = @topics[3]
	    @motocross = @topics[5]
	    @circletrack = @topics[6]
	    @dirttrack = @topics[7]
	    @offroad = @topics[8]
	    @tractor = @topics[9]
	    @general = @topics[10]
	end
end
