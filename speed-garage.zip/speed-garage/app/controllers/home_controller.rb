class HomeController < ApplicationController
	def index
		@posts = Post.all.order(created_at: :desc)
		@blogs = Blog.all.order(created_at: :desc)

		@categories = Category.all
        @oval = @categories[0]
        @atv = @categories[1]
        @boat = @categories[2]
        @fab = @categories[3]
        @chassis = @categories[4]
        @classic = @categories[5]
        @dirt = @categories[6]
        @dragracing = @categories[7]
        @audio = @categories[8]
        @engine = @categories[9]
        @tune = @categories[10]
        @enginecom = @categories[11]
        @exhaust = @categories[12]
        @golfcart = @categories[13]
        @hotrod = @categories[14]
        @karts = @categories[15]
        @modern = @categories[16]
        @motorcycle = @categories[17]
        @muscle = @categories[18]
        @offroad = @categories[19]
        @racingitem = @categories[20]
        @accessories = @categories[21]
        @position = @categories[22]
        @racingeq = @categories[23]
        @roadracing = @categories[24]
        @safety = @categories[25]
        @snowmobile = @categories[26]
        @tw = @categories[27]
        @tools = @categories[28]
        @rvs = @categories[29]
        @tractor = @categories[30]
        @trailer = @categories[31]
        @transmission = @categories[32]
        @truckpart = @categories[33]
        @drift = @categories[34]
        @import = @categories[35]
	end

	def business_directory
	end

	def partner
	end

    def about
    end

    def contact
    end

end