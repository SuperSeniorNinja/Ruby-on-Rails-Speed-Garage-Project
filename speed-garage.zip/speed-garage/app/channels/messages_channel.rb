class MessagesChannel < ApplicationCable::Channel
end