module PlanHelper
	def plan
		 [ 
      ['Free', 'Free'],
      ['Promote 2 days ($2.99)', 'bronze'],
      ['Promote 5 days ($4.99)', 'silver'],
      ['Promote 12 days ($11.99)', 'gold'],
      ['Promote 21 days ($16.99)', 'platnium'],
      ['Promote 30 days ($22.99)', 'platnium1x'],
      ['Life time ($29.99)', 'platnium2x']
    ]
	end
end