class Feature < ApplicationRecord
  belongs_to :post
end
