class Category < ApplicationRecord
	has_many :subcategories
	has_many :posts

	extend FriendlyId
	friendly_id :slug_candidates, use: %i[slugged finders]

	def slug_candidates
		[
			:name,
			[:name, :id]
		]
	end
end
