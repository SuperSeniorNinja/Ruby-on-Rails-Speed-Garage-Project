class Post < ApplicationRecord
  searchkick
  
  belongs_to :category
  belongs_to :subcategory
  belongs_to :user
  has_one :feature
  validates :category_id, :subcategory_id, presence: true
  validates :title, :price, :description, :email, :trades, :shipping, :condition, :country, :state, presence: true
  validates :images, presence: true


  has_many_attached :images, dependent: :destroy
  validate :validates_posts!, on: :create

  extend FriendlyId
  friendly_id :title, use: :slugged

  before_create :assign_unique_ad_number
  validates! :ad_number, uniqueness: true

  def thumbnail input
    return self.images[input].variant(resize: '625x415!').processed
  end
  
  private

  AD_NUMBER_RANGE = (10_0000000..99_99999999)

  def assign_unique_ad_number
    self.ad_number = loop do
      number = rand(AD_NUMBER_RANGE)
      break number unless Post.exists?(ad_number: number)
    end
  end

  def validates_posts!
		return if user.nil?
		 if  user.posts.count > 14
		 	errors.add(:base, 'You have exceed the maximum amount of listings')
		 end
  	end
end
