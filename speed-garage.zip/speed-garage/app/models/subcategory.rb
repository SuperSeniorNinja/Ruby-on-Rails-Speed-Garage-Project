class Subcategory < ApplicationRecord
  belongs_to :category
  has_many :posts

  extend FriendlyId
  friendly_id :slug_candidates, use: %i[slugged finders]

  def slug_candidates
		[
			:name,
			[:name, :id]
		]
	end
end
