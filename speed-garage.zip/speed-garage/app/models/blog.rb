class Blog < ApplicationRecord
  belongs_to :topic
  has_one_attached :image

  extend FriendlyId
  friendly_id :title, use: :slugged
end
